const oracleconnection = require('./conn');
const services = require('./services');
//import { services } from ('./services');
var DomParser = require('dom-parser');
const oracledb = require('oracledb');
const soapRequest = require('easy-soap-request');

async function spousesoapUI(arrayforitrate,accHCCID,beneHCCID,zipode,statecode,SSN,sub_id) {
	//SOAP Connection
	var memberid;
   console.log(arrayforitrate[0].firstname)
	console.log(arrayforitrate[1].lastName);
	console.log(arrayforitrate[0].lastName);
	console.log(arrayforitrate[1].lastName);
	console.log(arrayforitrate[0].memberid)
	console.log(arrayforitrate[1].memberid)

	console.log(arrayforitrate[0].gender)
	console.log(arrayforitrate[1].gender)

	console.log(arrayforitrate[0].dob)
	console.log(arrayforitrate[1].dob)

	console.log(arrayforitrate[0].address)
	console.log(arrayforitrate[1].address)

	console.log(statecode)
	console.log(zipode)

console.log("HCC:"+accHCCID + beneHCCID);

 
	const url = 'http://100.112.45.153:8181/connector/services/v4/EnrollmentSparse';
	const sampleHeaders = {
		'Content-Type': 'text/xml;charset=UTF-8',
		'soapAction': 'http://healthedge.com/submit',
		'Authorization': 'Basic Y29ubmVjdG9yOkNvbm5lY3RvcjEyMw=='
	};
	const datatoberetrive= (async () => {
		const xml = `<?xml version="1.0" encoding="UTF-8"?>
		<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:enr="http://www.healthedge.com/connector/schema/enrollmentsparse">
			<soapenv:Header/>
			<soapenv:Body>
				<NS1:enrollment
					xmlns:NS1="http://www.healthedge.com/connector/schema/enrollmentsparse">
					<actionMode>SPARSE</actionMode>
					<cascadeTerms>false</cascadeTerms>
					<subscription>
						<hccIdentifier>${sub_id}</hccIdentifier>
						<subscriptionUDTList>
							<listMode>DEFAULT</listMode>
						</subscriptionUDTList>
						<accountMatchData>
							<accountHccIdentifier>
								<accountHccIdentificationNumber>${accHCCID}</accountHccIdentificationNumber>
							</accountHccIdentifier>
						</accountMatchData>
						<informationSourceCode>
							<codeSetName>InformationSource</codeSetName>
							<codeEntry>4</codeEntry>
							<!--                <shortName>Claim</shortName> -->
						</informationSourceCode>
						<claimReviewList>
							<listMode>DEFAULT</listMode>
						</claimReviewList>
					</subscription>
					<member>
						<maintenanceTypeCode>CREATE</maintenanceTypeCode>
						<memberIsSubscriber>1</memberIsSubscriber>
						<hccIdentifier>${arrayforitrate[0].memberid}</hccIdentifier>
						<individual>
							<taxIdentificationNumber>${arrayforitrate[0].SSN}</taxIdentificationNumber>
							<genderCode>${arrayforitrate[0].gender}</genderCode>
							<birthDate>${arrayforitrate[0].dob}</birthDate>
							<primaryName>
								<lastName>${arrayforitrate[0].lastName}</lastName>
								<firstName>${arrayforitrate[0].firstname}</firstName>
								<middleName/>
								<nameSuffixList>
									<listMode>REPLACE</listMode>
								</nameSuffixList>
							</primaryName>
							<languages>
								<language>
									<primaryLanguage>1</primaryLanguage>
									<languageDomainCode>
										<codeEntry>EN</codeEntry>
									</languageDomainCode>
								</language>
							</languages>
						</individual>
						<physicalAddress>
							<listMode>DEFAULT</listMode>
							<memberPhysicalAddress>
								<addressInfo>
									<postalAddress>
										<address>${arrayforitrate[0].address}</address>
										<stateCode>${statecode}</stateCode>
										<zipCode>${zipode}</zipCode>
										<cityName>Burlington</cityName>
										<ignoreAddressCheck>true</ignoreAddressCheck>
									</postalAddress>
									<addressPhoneList>
										<listMode>REPLACE</listMode>
										<telephoneNumber>
											<phoneAreaCode>301</phoneAreaCode>
											<phoneNumber>1234567</phoneNumber>
											<individualPhoneTypeCode>
												<codeEntry>HP</codeEntry>
											</individualPhoneTypeCode>
										</telephoneNumber>
									</addressPhoneList>
								</addressInfo>
								<addressTypeCode>
									<codeSetName>IndividualAddressType</codeSetName>
									<codeEntry>2</codeEntry>
								</addressTypeCode>
							</memberPhysicalAddress>
						</physicalAddress>
						<relationshipToSubscriberDefinitionReference>
							<reference>
								<ID>Self</ID>
							</reference>
						</relationshipToSubscriberDefinitionReference>
						<planSelection>
							<startDate>2023-04-01</startDate>
							<benefitPlanMatchData>
								<benefitPlanHccId>${beneHCCID}</benefitPlanHccId>
							</benefitPlanMatchData>
							<!--                <healthCoverageMaintenanceCode>CREATE</healthCoverageMaintenanceCode> -->
							<!--                <insuranceLineCode>HLT</insuranceLineCode> -->
						</planSelection>
					</member>
					<member>
						<maintenanceTypeCode>CREATE</maintenanceTypeCode>
						<memberIsSubscriber>false</memberIsSubscriber>
						<hccIdentifier>${arrayforitrate[1].memberid}</hccIdentifier>
						<individual>
							<taxIdentificationNumber>${arrayforitrate[1].SSN}</taxIdentificationNumber>
							<genderCode>${arrayforitrate[1].gender}</genderCode>
							<birthDate>${arrayforitrate[1].dob}</birthDate>
							<primaryName>
								<lastName>${arrayforitrate[1].lastName}</lastName>
								<firstName>${arrayforitrate[1].firstname}</firstName>
								<middleName/>
								<nameSuffixList>
									<listMode>REPLACE</listMode>
								</nameSuffixList>
							</primaryName>
							<languages>
								<language>
									<primaryLanguage>1</primaryLanguage>
									<languageDomainCode>
										<codeEntry>EN</codeEntry>
									</languageDomainCode>
								</language>
							</languages>
						</individual>
						<physicalAddress>
							<listMode>DEFAULT</listMode>
							<memberPhysicalAddress>
								<addressInfo>
									<postalAddress>
										<address>${arrayforitrate[1].address}</address>
										<stateCode>${statecode}</stateCode>
										<zipCode>${zipode}</zipCode>
										<cityName>Burlington</cityName>
										<ignoreAddressCheck>true</ignoreAddressCheck>
									</postalAddress>
									<addressPhoneList>
										<listMode>REPLACE</listMode>
										<telephoneNumber>
											<phoneAreaCode>301</phoneAreaCode>
											<phoneNumber>1234567</phoneNumber>
											<individualPhoneTypeCode>
												<codeEntry>HP</codeEntry>
											</individualPhoneTypeCode>
										</telephoneNumber>
									</addressPhoneList>
								</addressInfo>
								<addressTypeCode>
									<codeSetName>IndividualAddressType</codeSetName>
									<codeEntry>2</codeEntry>
								</addressTypeCode>
							</memberPhysicalAddress>
						</physicalAddress>
						<relationshipToSubscriberDefinitionReference>
							<reference>
								<ID>Spouse</ID>
							</reference>
						</relationshipToSubscriberDefinitionReference>
						<planSelection>
							<startDate>2023-04-01</startDate>
							<benefitPlanMatchData>
								<benefitPlanHccId>${beneHCCID}</benefitPlanHccId>
							</benefitPlanMatchData>
							<!--                <healthCoverageMaintenanceCode>CREATE</healthCoverageMaintenanceCode> -->
							<!--                <insuranceLineCode>HLT</insuranceLineCode> -->
						</planSelection>
					</member>
				</NS1:enrollment>
			</soapenv:Body>
		</soapenv:Envelope>
 `
 const { response } = await soapRequest({ url: url, headers: sampleHeaders, xml: xml });
 const { headers, body, statusCode } = response;
 console.log(body);
 console.log(response);
 memberid=JSON.stringify(memberidextract(body));
 return{
   memberid
 }
 })();
 
 console.log("mem:"+datatoberetrive)
 }


async function childsoapUI(arrayforitrate,accHCCID,beneHCCID,zipode,statecode,SSN,sub_id) {
	//SOAP Connection
	var memberid;
   //console.log(arrayforitrate[0].firstname);
   console.log(arrayforitrate[0].firstname)
   console.log(arrayforitrate[1].lastName);
   console.log(arrayforitrate[0].lastName);
   console.log(arrayforitrate[1].lastName);
   console.log(arrayforitrate[0].memberid)
   console.log(arrayforitrate[1].memberid)

   console.log(arrayforitrate[0].gender)
   console.log(arrayforitrate[1].gender)

   console.log(arrayforitrate[0].dob)
   console.log(arrayforitrate[1].dob)

   console.log(arrayforitrate[0].address)
   console.log(arrayforitrate[1].address)

   console.log(statecode)
   console.log(zipode)

	const url = 'http://100.112.45.153:8181/connector/services/v4/EnrollmentSparse';
	const sampleHeaders = {
		'Content-Type': 'text/xml;charset=UTF-8',
		'soapAction': 'http://healthedge.com/submit',
		'Authorization': 'Basic Y29ubmVjdG9yOkNvbm5lY3RvcjEyMw=='
	};
	const datatoberetrive=  (async () => {
		const xml = `
		<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:enr="http://www.healthedge.com/connector/schema/enrollmentsparse">
			<soapenv:Header/>
			<soapenv:Body>
				<NS1:enrollment
					xmlns:NS1="http://www.healthedge.com/connector/schema/enrollmentsparse">
					<actionMode>SPARSE</actionMode>
					<cascadeTerms>false</cascadeTerms>
					<subscription>
						<hccIdentifier>${sub_id}</hccIdentifier>
						<subscriptionUDTList>
							<listMode>DEFAULT</listMode>
						</subscriptionUDTList>
						<accountMatchData>
							<accountHccIdentifier>
								<accountHccIdentificationNumber>${accHCCID}</accountHccIdentificationNumber>
							</accountHccIdentifier>
						</accountMatchData>
						<informationSourceCode>
							<codeSetName>InformationSource</codeSetName>
							<codeEntry>4</codeEntry>
							<!--                <shortName>Claim</shortName> -->
						</informationSourceCode>
						<claimReviewList>
							<listMode>DEFAULT</listMode>
						</claimReviewList>
					</subscription>
					<member>
						<maintenanceTypeCode>CREATE</maintenanceTypeCode>
						<memberIsSubscriber>1</memberIsSubscriber>
						<hccIdentifier>${arrayforitrate[0].memberid}</hccIdentifier>
						<individual>
							<taxIdentificationNumber>${arrayforitrate[0].SSN}</taxIdentificationNumber>
							<genderCode>${arrayforitrate[0].gender}</genderCode>
							<birthDate>${arrayforitrate[0].dob}</birthDate>
							<primaryName>
								<lastName>${arrayforitrate[0].lastName}</lastName>
								<firstName>${arrayforitrate[0].firstname}</firstName>
								<middleName/>
								<nameSuffixList>
									<listMode>REPLACE</listMode>
								</nameSuffixList>
							</primaryName>
							<languages>
								<language>
									<primaryLanguage>1</primaryLanguage>
									<languageDomainCode>
										<codeEntry>EN</codeEntry>
									</languageDomainCode>
								</language>
							</languages>
						</individual>
						<physicalAddress>
							<listMode>DEFAULT</listMode>
							<memberPhysicalAddress>
								<addressInfo>
									<postalAddress>
										<address>${arrayforitrate[0].address}</address>
										<stateCode>${statecode}</stateCode>
										<zipCode>${zipode}</zipCode>
										<cityName>Burlington</cityName>
										<ignoreAddressCheck>true</ignoreAddressCheck>
									</postalAddress>
									<addressPhoneList>
										<listMode>REPLACE</listMode>
										<telephoneNumber>
											<phoneAreaCode>301</phoneAreaCode>
											<phoneNumber>1234567</phoneNumber>
											<individualPhoneTypeCode>
												<codeEntry>HP</codeEntry>
											</individualPhoneTypeCode>
										</telephoneNumber>
									</addressPhoneList>
								</addressInfo>
								<addressTypeCode>
									<codeSetName>IndividualAddressType</codeSetName>
									<codeEntry>2</codeEntry>
								</addressTypeCode>
							</memberPhysicalAddress>
						</physicalAddress>
						<relationshipToSubscriberDefinitionReference>
							<reference>
								<ID>Self</ID>
							</reference>
						</relationshipToSubscriberDefinitionReference>
						<planSelection>
							<startDate>2023-04-01</startDate>
							<benefitPlanMatchData>
								<benefitPlanHccId>${beneHCCID}</benefitPlanHccId>
							</benefitPlanMatchData>
							<!--                <healthCoverageMaintenanceCode>CREATE</healthCoverageMaintenanceCode> -->
							<!--                <insuranceLineCode>HLT</insuranceLineCode> -->
						</planSelection>
					</member>
					<member>
						<maintenanceTypeCode>CREATE</maintenanceTypeCode>
						<memberIsSubscriber>false</memberIsSubscriber>
						<hccIdentifier>${arrayforitrate[1].memberid}</hccIdentifier>
						<individual>
							<taxIdentificationNumber>${arrayforitrate[1].SSN}</taxIdentificationNumber>
							<genderCode>${arrayforitrate[1].gender}</genderCode>
							<birthDate>${arrayforitrate[1].dob}</birthDate>
							<primaryName>
								<lastName>${arrayforitrate[1].lastName}</lastName>
								<firstName>${arrayforitrate[1].firstname}</firstName>
								<middleName/>
								<nameSuffixList>
									<listMode>REPLACE</listMode>
								</nameSuffixList>
							</primaryName>
							<languages>
								<language>
									<primaryLanguage>1</primaryLanguage>
									<languageDomainCode>
										<codeEntry>EN</codeEntry>
									</languageDomainCode>
								</language>
							</languages>
						</individual>
						<physicalAddress>
							<listMode>DEFAULT</listMode>
							<memberPhysicalAddress>
								<addressInfo>
									<postalAddress>
										<address>${arrayforitrate[1].address}</address>
										<stateCode>${statecode}</stateCode>
										<zipCode>${zipode}</zipCode>
										<cityName>Burlington</cityName>
										<ignoreAddressCheck>true</ignoreAddressCheck>
									</postalAddress>
									<addressPhoneList>
										<listMode>REPLACE</listMode>
										<telephoneNumber>
											<phoneAreaCode>301</phoneAreaCode>
											<phoneNumber>1234567</phoneNumber>
											<individualPhoneTypeCode>
												<codeEntry>HP</codeEntry>
											</individualPhoneTypeCode>
										</telephoneNumber>
									</addressPhoneList>
								</addressInfo>
								<addressTypeCode>
									<codeSetName>IndividualAddressType</codeSetName>
									<codeEntry>2</codeEntry>
								</addressTypeCode>
							</memberPhysicalAddress>
						</physicalAddress>
						<relationshipToSubscriberDefinitionReference>
							<reference>
								<ID>Child</ID>
							</reference>
						</relationshipToSubscriberDefinitionReference>
						<planSelection>
							<startDate>2023-04-01</startDate>
							<benefitPlanMatchData>
								<benefitPlanHccId>${beneHCCID}</benefitPlanHccId>
							</benefitPlanMatchData>
							<!--                <healthCoverageMaintenanceCode>CREATE</healthCoverageMaintenanceCode> -->
							<!--                <insuranceLineCode>HLT</insuranceLineCode> -->
						</planSelection>
					</member>
				</NS1:enrollment>
			</soapenv:Body>
		</soapenv:Envelope>
 `
 const { response } = await soapRequest({ url: url, headers: sampleHeaders, xml: xml });
 const { headers, body, statusCode } = response;
 console.log(body);
 //console.log(response);
 memberid=JSON.stringify(memberidextract(body));
 return{
   memberid
 }
 })();
 
 console.log("mem:"+datatoberetrive)
 }
 
async function familysoapUI(arrayforitrate,accHCCID,beneHCCID,zipode,statecode,SSN,sub_id) {
   //SOAP Connection
   var memberid;
 // console.log(arrayforitrate[0].firstname);
 console.log(arrayforitrate[0].firstname)
	console.log(arrayforitrate[1].lastName);
	console.log(arrayforitrate[0].lastName);
	console.log(arrayforitrate[1].lastName);
	console.log(arrayforitrate[0].memberid)
	console.log(arrayforitrate[1].memberid)

	console.log(arrayforitrate[0].gender)
	console.log(arrayforitrate[1].gender)

	console.log(arrayforitrate[0].dob)
	console.log(arrayforitrate[1].dob)

	console.log(arrayforitrate[0].address)
	console.log(arrayforitrate[1].address)

	console.log(statecode)
	console.log(zipode)


   const url = 'http://100.112.45.153:8181/connector/services/v4/EnrollmentSparse';
   const sampleHeaders = {
       'Content-Type': 'text/xml;charset=UTF-8',
       'soapAction': 'http://healthedge.com/submit',
       'Authorization': 'Basic Y29ubmVjdG9yOkNvbm5lY3RvcjEyMw=='
   };
   const datatoberetrive=  (async () => {
       const xml = `<?xml version="1.0" encoding="UTF-8"?>
       <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:enr="http://www.healthedge.com/connector/schema/enrollmentsparse">
	<soapenv:Header/>
	<soapenv:Body>
		<NS1:enrollment
			xmlns:NS1="http://www.healthedge.com/connector/schema/enrollmentsparse">
			<actionMode>SPARSE</actionMode>
			<cascadeTerms>false</cascadeTerms>
			<subscription>
				<hccIdentifier>${sub_id}</hccIdentifier>
				<subscriptionUDTList>
					<listMode>DEFAULT</listMode>
				</subscriptionUDTList>
				<accountMatchData>
					<accountHccIdentifier>
						<accountHccIdentificationNumber>${accHCCID}</accountHccIdentificationNumber>
					</accountHccIdentifier>
				</accountMatchData>
				<informationSourceCode>
					<codeSetName>InformationSource</codeSetName>
					<codeEntry>4</codeEntry>
					<!--                <shortName>Claim</shortName> -->
				</informationSourceCode>
				<claimReviewList>
					<listMode>DEFAULT</listMode>
				</claimReviewList>
			</subscription>
			<member>
				<maintenanceTypeCode>CREATE</maintenanceTypeCode>
				<memberIsSubscriber>1</memberIsSubscriber>
				<hccIdentifier>${arrayforitrate[0].memberid}</hccIdentifier>
				<individual>
					<taxIdentificationNumber>${arrayforitrate[0].SSN}</taxIdentificationNumber>
					<genderCode>${arrayforitrate[0].gender}</genderCode>
					<birthDate>${arrayforitrate[0].dob}</birthDate>
					<primaryName>
						<lastName>${arrayforitrate[0].lastName}</lastName>
						<firstName>${arrayforitrate[0].firstname}</firstName>
						<middleName/>
						<nameSuffixList>
							<listMode>REPLACE</listMode>
						</nameSuffixList>
					</primaryName>
					<languages>
						<language>
							<primaryLanguage>1</primaryLanguage>
							<languageDomainCode>
								<codeEntry>EN</codeEntry>
							</languageDomainCode>
						</language>
					</languages>
				</individual>
				<physicalAddress>
					<listMode>DEFAULT</listMode>
					<memberPhysicalAddress>
						<addressInfo>
							<postalAddress>
								<address>${arrayforitrate[0].address}</address>
								<stateCode>${statecode}</stateCode>
								<zipCode>${zipode}</zipCode>
								<cityName>Burlington</cityName>
								<ignoreAddressCheck>true</ignoreAddressCheck>
							</postalAddress>
							<addressPhoneList>
								<listMode>REPLACE</listMode>
								<telephoneNumber>
									<phoneAreaCode>301</phoneAreaCode>
									<phoneNumber>1234567</phoneNumber>
									<individualPhoneTypeCode>
										<codeEntry>HP</codeEntry>
									</individualPhoneTypeCode>
								</telephoneNumber>
							</addressPhoneList>
						</addressInfo>
						<addressTypeCode>
							<codeSetName>IndividualAddressType</codeSetName>
							<codeEntry>2</codeEntry>
						</addressTypeCode>
					</memberPhysicalAddress>
				</physicalAddress>
				<relationshipToSubscriberDefinitionReference>
					<reference>
						<ID>Self</ID>
					</reference>
				</relationshipToSubscriberDefinitionReference>
				<planSelection>
					<startDate>2023-04-01</startDate>
					<benefitPlanMatchData>
						<benefitPlanHccId>${beneHCCID}</benefitPlanHccId>
					</benefitPlanMatchData>
				</planSelection>
			</member>
			<member>
				<maintenanceTypeCode>CREATE</maintenanceTypeCode>
				<memberIsSubscriber>false</memberIsSubscriber>
				<hccIdentifier>${arrayforitrate[1].memberid}</hccIdentifier>
				<individual>
					<taxIdentificationNumber>${arrayforitrate[1].SSN}</taxIdentificationNumber>
					<genderCode>${arrayforitrate[1].gender}</genderCode>
					<birthDate>${arrayforitrate[1].dob}</birthDate>
					<primaryName>
						<lastName>${arrayforitrate[1].lastName}</lastName>
						<firstName>${arrayforitrate[1].firstname}</firstName>
						<middleName/>
						<nameSuffixList>
							<listMode>REPLACE</listMode>
						</nameSuffixList>
					</primaryName>
					<languages>
						<language>
							<primaryLanguage>1</primaryLanguage>
							<languageDomainCode>
								<codeEntry>EN</codeEntry>
							</languageDomainCode>
						</language>
					</languages>
				</individual>
				<physicalAddress>
					<listMode>DEFAULT</listMode>
					<memberPhysicalAddress>
						<addressInfo>
							<postalAddress>
								<address>${arrayforitrate[1].address}</address>
								<stateCode>${statecode}</stateCode>
								<zipCode>${zipode}</zipCode>
								<cityName>Burlington</cityName>
								<ignoreAddressCheck>true</ignoreAddressCheck>
							</postalAddress>
							<addressPhoneList>
								<listMode>REPLACE</listMode>
								<telephoneNumber>
									<phoneAreaCode>301</phoneAreaCode>
									<phoneNumber>1234567</phoneNumber>
									<individualPhoneTypeCode>
										<codeEntry>HP</codeEntry>
									</individualPhoneTypeCode>
								</telephoneNumber>
							</addressPhoneList>
						</addressInfo>
						<addressTypeCode>
							<codeSetName>IndividualAddressType</codeSetName>
							<codeEntry>2</codeEntry>
						</addressTypeCode>
					</memberPhysicalAddress>
				</physicalAddress>
				<relationshipToSubscriberDefinitionReference>
					<reference>
						<ID>Spouse</ID>
					</reference>
				</relationshipToSubscriberDefinitionReference>
				<planSelection>
					<startDate>2023-04-01</startDate>
					<benefitPlanMatchData>
						<benefitPlanHccId>${beneHCCID}</benefitPlanHccId>
					</benefitPlanMatchData>
					<!--                <healthCoverageMaintenanceCode>CREATE</healthCoverageMaintenanceCode> -->
					<!--                <insuranceLineCode>HLT</insuranceLineCode> -->
				</planSelection>
			</member>
			<member>
				<maintenanceTypeCode>CREATE</maintenanceTypeCode>
				<memberIsSubscriber>false</memberIsSubscriber>
				<hccIdentifier>${arrayforitrate[2].memberid}</hccIdentifier>
				<individual>
					<taxIdentificationNumber>${arrayforitrate[2].SSN}</taxIdentificationNumber>
					<genderCode>${arrayforitrate[2].gender}</genderCode>
					<birthDate>${arrayforitrate[2].dob}</birthDate>
					<primaryName>
						<lastName>${arrayforitrate[2].lastName}</lastName>
						<firstName>${arrayforitrate[2].firstName}</firstName>
						<middleName/>
						<nameSuffixList>
							<listMode>REPLACE</listMode>
						</nameSuffixList>
					</primaryName>
					<languages>
						<language>
							<primaryLanguage>1</primaryLanguage>
							<languageDomainCode>
								<codeEntry>EN</codeEntry>
							</languageDomainCode>
						</language>
					</languages>
				</individual>
				<physicalAddress>
					<listMode>DEFAULT</listMode>
					<memberPhysicalAddress>
						<addressInfo>
							<postalAddress>
								<address>${arrayforitrate[2].address}</address>
								<stateCode>${statecode}</stateCode>
								<zipCode>${zipode}</zipCode>
								<cityName>Burlington</cityName>
								<ignoreAddressCheck>true</ignoreAddressCheck>
							</postalAddress>
							<addressPhoneList>
								<listMode>REPLACE</listMode>
								<telephoneNumber>
									<phoneAreaCode>301</phoneAreaCode>
									<phoneNumber>1234567</phoneNumber>
									<individualPhoneTypeCode>
										<codeEntry>HP</codeEntry>
									</individualPhoneTypeCode>
								</telephoneNumber>
							</addressPhoneList>
						</addressInfo>
						<addressTypeCode>
							<codeSetName>IndividualAddressType</codeSetName>
							<codeEntry>2</codeEntry>
						</addressTypeCode>
					</memberPhysicalAddress>
				</physicalAddress>
				<relationshipToSubscriberDefinitionReference>
					<reference>
						<ID>Child</ID>
					</reference>
				</relationshipToSubscriberDefinitionReference>
				<planSelection>
					<startDate>2023-04-01</startDate>
					<benefitPlanMatchData>
						<benefitPlanHccId>${beneHCCID}</benefitPlanHccId>
					</benefitPlanMatchData>
					</planSelection>
					</member>
				</NS1:enrollment>
			</soapenv:Body>
		</soapenv:Envelope>
`
const { response } = await soapRequest({ url: url, headers: sampleHeaders, xml: xml });
const { headers, body, statusCode } = response;
console.log(body);
//console.log(response);
memberid=JSON.stringify(memberidextract(body));
return{
  memberid
}
})();

console.log("mem:"+datatoberetrive)
}


async function SOAPUIConfig(firstname,lastName,address,state,gender,dob,accHCCID,beneHCCID,zipode,statecode,SSN,subname,sub_id,memberidref) {
    //SOAP Connection
    var memberid;
   //console.log("passing"+beneHCCID);

    const url = 'http://100.112.45.153:8181/connector/services/v4/EnrollmentSparse';
    const sampleHeaders = {
        'Content-Type': 'text/xml;charset=UTF-8',
        'soapAction': 'http://healthedge.com/submit',
        'Authorization': 'Basic Y29ubmVjdG9yOkNvbm5lY3RvcjEyMw=='
    };
    const datatoberetrive=  (async () => {
        const xml = `<?xml version="1.0" encoding="UTF-8"?>
        <soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:enr="http://www.healthedge.com/connector/schema/enrollmentsparse">
           <soapenv:Header/>
           <soapenv:Body>
              <NS1:enrollment xmlns:NS1="http://www.healthedge.com/connector/schema/enrollmentsparse">
                 <actionMode>SPARSE</actionMode>
                 <cascadeTerms>false</cascadeTerms>
                 <subscription>
                 <hccIdentifier>${sub_id}</hccIdentifier>

                    <subscriptionUDTList>
                       <listMode>DEFAULT</listMode>
                    </subscriptionUDTList>
                    <accountMatchData>
                       <accountHccIdentifier>
                          <accountHccIdentificationNumber>${accHCCID}</accountHccIdentificationNumber>
                       </accountHccIdentifier>
                    </accountMatchData>
                                        <informationSourceCode>
                       <codeSetName>InformationSource</codeSetName>
                       <codeEntry>4</codeEntry>
        <!--               <shortName>Claim</shortName>-->
                    </informationSourceCode>  
                    <claimReviewList>
                       <listMode>DEFAULT</listMode>
                    </claimReviewList>     
                 </subscription>
           
                 <member>
                    <maintenanceTypeCode>CREATE</maintenanceTypeCode>
                    <memberIsSubscriber>1</memberIsSubscriber>
                    <hccIdentifier>${memberidref}</hccIdentifier>

                    <individual>
                    <taxIdentificationNumber>${SSN}</taxIdentificationNumber>
                       <genderCode>${gender}</genderCode>
                       <birthDate>${dob}</birthDate>
                       <primaryName>
                          <lastName>${lastName}</lastName>
                          <firstName>${firstname}</firstName>
                          <middleName/>
                          <nameSuffixList>
                             <listMode>REPLACE</listMode>
                          </nameSuffixList>
                       </primaryName>
                       <languages>
                          <language>
                             <primaryLanguage>1</primaryLanguage>
                             <languageDomainCode>
                                <codeEntry>EN</codeEntry>
                             </languageDomainCode>
                          </language>
                       </languages>
                    </individual>
                    <physicalAddress>
                       <listMode>DEFAULT</listMode>
                       <memberPhysicalAddress>
                          <addressInfo>
                             <postalAddress>
                                <address>${address}</address>
                                <stateCode>${statecode}</stateCode>
                                <zipCode>${zipode}</zipCode>
                                <cityName>Burlington</cityName>
                                <ignoreAddressCheck>true</ignoreAddressCheck>
                             </postalAddress>
                             <addressPhoneList>
                                <listMode>REPLACE</listMode>
                                <telephoneNumber>
                                   <phoneAreaCode>301</phoneAreaCode>
                                   <phoneNumber>1234567</phoneNumber>
                                   <individualPhoneTypeCode>
                                      <codeEntry>HP</codeEntry>
                                   </individualPhoneTypeCode>
                                </telephoneNumber>
                             </addressPhoneList>
                          </addressInfo>
                          <addressTypeCode>
                             <codeSetName>IndividualAddressType</codeSetName>
                             <codeEntry>2</codeEntry>
                          </addressTypeCode>
                       </memberPhysicalAddress>
                    </physicalAddress>
                    <relationshipToSubscriberDefinitionReference>
                       <reference>
                          <ID>${subname}</ID>
                       </reference>
                    </relationshipToSubscriberDefinitionReference>
        
                    <planSelection>
                       <startDate>2023-04-05</startDate>
                       <benefitPlanMatchData>
                          <benefitPlanHccId>${beneHCCID}</benefitPlanHccId>
                       </benefitPlanMatchData>
                    </planSelection>
        
                 </member>
              </NS1:enrollment>
           </soapenv:Body>
        </soapenv:Envelope>
`
const { response } = await soapRequest({ url: url, headers: sampleHeaders, xml: xml });
const { headers, body, statusCode } = response;
//console.log(body);
//console.log(response);
memberid=JSON.stringify(memberidextract(body));
return{
   memberid
}
})();

console.log("mem:"+datatoberetrive)
}


function memberidextract(soapResponse) {
    debugger;
    try {
      var member_Id='';
        var DomParser = require('dom-parser');
        var parser = new DomParser();
        const xmlDocument = parser.parseFromString(soapResponse, "text/xml");
        const member = xmlDocument.getElementsByTagName("memberId")[0];
        member_Id = member.textContent;
        //console.log("member_Id"+member_Id);
    } catch (e) {
        console.log(e)
    }

    return {
      member_Id
  }
  
}
async function getdbvalue(name,acckey) 
{
   try{
    connection = await oracledb.getConnection({
        user: 'citi_abagchi',
        password: 'U4ggPVAg9PNuJ',
        connectString: '100.112.45.151:1521/CITPDWTT'
    });
    
    //console.log(name+" "+acckey);
    if(name=="statecode")
    {
      //statecode
      const query = await connection.execute("SELECT SC.STATE_CODE FROM PAYOR_DW.ALL_ACCOUNT_HISTORY_FACT AHF INNER JOIN PAYOR_DW.DATE_DIMENSION EFFDT ON EFFDT.DATE_KEY = AHF.VERSION_EFF_DATE_KEY INNER JOIN PAYOR_DW.DATE_DIMENSION EXPDT ON EXPDT.DATE_KEY = AHF.VERSION_EXP_DATE_KEY LEFT OUTER JOIN PAYOR_DW.TAX_ENTITY TEHF ON AHF.TAX_ENTITY_KEY = TEHF.TAX_ENTITY_KEY INNER JOIN PAYOR_DW.POSTAL_ADDRESS PA ON PA.POSTAL_ADDRESS_KEY = AHF.ACCOUNT_CORR_ADDRESS_KEY INNER JOIN PAYOR_DW.STATE_CODE SC ON SC.STATE_CODE = PA.STATE_CODE WHERE EFFDT.DATE_VALUE <= SYSDATE AND EXPDT.DATE_VALUE > SYSDATE AND AHF.account_key='"+acckey+"'");
      var code = query.rows[0][0];
      
      console.log("statecode"+code);
    }
    if(name=="AccHcc")
    {
      //statecode
      const query = await connection.execute("SELECT AHF.ACCOUNT_HCC_ID FROM PAYOR_DW.ALL_ACCOUNT_HISTORY_FACT AHF INNER JOIN PAYOR_DW.DATE_DIMENSION EFFDT ON EFFDT.DATE_KEY = AHF.VERSION_EFF_DATE_KEY INNER JOIN PAYOR_DW.DATE_DIMENSION EXPDT ON EXPDT.DATE_KEY = AHF.VERSION_EXP_DATE_KEY LEFT OUTER JOIN PAYOR_DW.TAX_ENTITY TEHF ON AHF.TAX_ENTITY_KEY = TEHF.TAX_ENTITY_KEY INNER JOIN PAYOR_DW.POSTAL_ADDRESS PA ON PA.POSTAL_ADDRESS_KEY = AHF.ACCOUNT_CORR_ADDRESS_KEY INNER JOIN PAYOR_DW.STATE_CODE SC ON SC.STATE_CODE = PA.STATE_CODE WHERE EFFDT.DATE_VALUE <= SYSDATE AND EXPDT.DATE_VALUE > SYSDATE AND AHF.Account_key='"+acckey+"'");
      var code = query.rows[0][0];
      console.log("ACC"+code);
    }
    if(name=="zipcode")
    {
      //zipcode
      const query = await connection.execute("SELECT PA.ZIP_CODE FROM PAYOR_DW.ALL_ACCOUNT_HISTORY_FACT AHF INNER JOIN PAYOR_DW.DATE_DIMENSION EFFDT ON EFFDT.DATE_KEY = AHF.VERSION_EFF_DATE_KEY INNER JOIN PAYOR_DW.DATE_DIMENSION EXPDT ON EXPDT.DATE_KEY = AHF.VERSION_EXP_DATE_KEY LEFT OUTER JOIN PAYOR_DW.TAX_ENTITY TEHF ON AHF.TAX_ENTITY_KEY = TEHF.TAX_ENTITY_KEY INNER JOIN PAYOR_DW.POSTAL_ADDRESS PA ON PA.POSTAL_ADDRESS_KEY = AHF.ACCOUNT_CORR_ADDRESS_KEY INNER JOIN PAYOR_DW.STATE_CODE SC ON SC.STATE_CODE = PA.STATE_CODE WHERE EFFDT.DATE_VALUE <= SYSDATE AND EXPDT.DATE_VALUE > SYSDATE AND AHF.Account_key='"+acckey+"'");
    var code = query.rows[0][0];
    console.log("zipcode"+code);
    }

    return {
      code
    }
   } catch (err) {
      console.error(err);
    } finally {
      if (connection) {
        try {
          await connection.close();
        } catch (err) {
          console.error(err);
        }
      }
    }
}


module.exports = {
   SOAPUIConfig, getdbvalue,memberidextract,familysoapUI,spousesoapUI,childsoapUI
 }