// const express = require('express');
// const router = express.Router();
// const accountColumns = require('./services');
// const postaccName = require('./post');


// router.post('/', async function(req, res) {
//   try {
//     const getBP = req.body.accName;
//     console.log(getBP);
//     await postaccName.getBenefitplans(getBP);
//     res.json({message: getBP});
//   } catch (err) {
//     console.error(`Error while getting Account Name `, err.message);
//   }
// });

// router.post('/', async function(req, res) {
//   try {
//       let Columndata = await postaccName.getBenefitplans(req.body.content);
//       var bpname = req.body;
//       console.log(bpname);
//       res.status(201).json(Columndata)
//     } catch (err) {
//     console.error(`Error while getting Account Name `, err.message);
//   }
// });
  
// module.exports = router;